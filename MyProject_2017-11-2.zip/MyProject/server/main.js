/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 4);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

module.exports = require("log4js");

/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
const privateKey = exports.privateKey = `-----BEGIN RSA PRIVATE KEY-----
MIICXQIBAAKBgQDH/b8R+bDeOArUlvxe7nN1gPTOoV3YmuwQoqH2B1TjfaADBMzZ
YnRJg+uBJ0dSYzGBj5yR/6jNNJG9ElM9oIXe4BZ5YGeAeUmdars9lgdbN3sYf9pV
7EZhuu7ClxSC75L0Ni8HlOhHXx6fS2VxN0Y8d5bYVeuD+WMDoxqaTJt80QIDAQAB
AoGAHqWg8SU9WGBoMHnOxNFvuhL/8OZDllzvTgFOJoCrHo1yxuOmbK2sulNP9KPL
RzHSNVOHn8v41zF2H+49+VSvDtmrE1jP/Ezo85escpT7kENwmS1YDsenx1ECsNCB
aqXpW93aDYB5eUsYttWb1X5yeKh04YuESJm0G0MWiUWPZn0CQQD84RXNe0ZKIvBl
c6ALeKmwxhyHIB4gD2G/6FJ5MFm4uoQNgeNRG6xulffIlN8Ix0GqdhniwJFoIJfv
oQhaNG2rAkEAynWSyPQz8RNXYekqvz4JHHDowNiziQ8VKyAV88Z19RsGUUJT8aTy
tsW7J+YiHmMQpfyFpaspRScSBVrr5mercwJBALa6+2NBShh2SNo2hBbl+VDIx4KJ
Hduy4cKn4Ti7TIolFRkhm55XbfF3ItbpZIVWXsgLkUb+OdRRgRjid0OfkQMCQGYF
o2cyb+4+wdzsA4eFek/jsdZkHOynNhKaQ5WpX42ZBbDzDJwLc+eYcnxjorPPVfde
7fYS72QSkSkzrQZZHXMCQQCtyYR7e8Ms0fdPjPjqvvHP2m3We7+s8sMBsOZ7gTz+
adXjcUTPQtyc+G2u7tCpYHAsQkTzRzBm3eZkl8+oQbWa
-----END RSA PRIVATE KEY-----`;

exports.default = {
  'request-token': 'unique-token',
  'dev-token': 'dev-token'
};

/***/ }),
/* 2 */
/***/ (function(module, exports) {

module.exports = require("koa-router");

/***/ }),
/* 3 */
/***/ (function(module, exports) {

module.exports = require("lodash");

/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(5);


/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _koa = __webpack_require__(6);

var _koa2 = _interopRequireDefault(_koa);

var _register = __webpack_require__(7);

var _register2 = _interopRequireDefault(_register);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// register middlewares
const { app, logger } = (0, _register2.default)(new _koa2.default());
const port = process.env.PORT || 2333;

app.listen(port);

logger.info(`Server [${process.pid}] is listening on ${port}`);

exports.default = app;

/***/ }),
/* 6 */
/***/ (function(module, exports) {

module.exports = require("koa");

/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _path = __webpack_require__(8);

var _path2 = _interopRequireDefault(_path);

var _koaStatic = __webpack_require__(9);

var _koaStatic2 = _interopRequireDefault(_koaStatic);

var _koaMount = __webpack_require__(10);

var _koaMount2 = _interopRequireDefault(_koaMount);

var _koaViews = __webpack_require__(11);

var _koaViews2 = _interopRequireDefault(_koaViews);

var _koaSession = __webpack_require__(12);

var _koaSession2 = _interopRequireDefault(_koaSession);

var _log4js = __webpack_require__(0);

var _log = __webpack_require__(13);

var _log2 = _interopRequireDefault(_log);

var _session = __webpack_require__(14);

var _session2 = _interopRequireDefault(_session);

var _enrich = __webpack_require__(15);

var _route = __webpack_require__(16);

var _route2 = _interopRequireDefault(_route);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// import koaCors from 'koa2-cors'

const webroot = _path2.default.join(__dirname, '../client');
const staticroot = _path2.default.join(__dirname, '../static');

// configure log4js
(0, _log4js.configure)(_log2.default);
const logger = (0, _log4js.getLogger)('server');

exports.default = app => {
  logger.debug('Registering middlewares for app...');

  app.env = process.env.NODE_ENV || app.env;

  logger.debug('Setting app env to', app.env);

  app.keys = ['this is a secret key hehe'];
  app.use((0, _koaSession2.default)(_session2.default, app));
  // app.use(koaCors({ credentials: true }))

  // serve pure static assets
  app.use((0, _koaMount2.default)('/static', (0, _koaStatic2.default)(staticroot)));

  if (app.env !== 'development') {
    logger.info('Setting packed resources directory', webroot, 'for env', process.env.NODE_ENV);
    app.use((0, _koaStatic2.default)(webroot));
    app.use((0, _koaViews2.default)(webroot, { extentions: 'html' }));
  }

  app.use(_enrich.enrichResponse);
  app.use(_enrich.enrichSession);

  app.use(async (ctx, next) => {
    try {
      await next();
    } catch (e) {
      logger.error('Uncaught exception:', e);
      ctx.status = 400;
      ctx.body = '你特么发了个什么鬼东西给服务器';
    }
  });

  app.use(_route2.default);

  app.use(async ctx => {
    if (!ctx.headerSent && app.env !== 'development') {
      await ctx.render('index.html');
    }
  });

  logger.debug('Middlewares registering completed\n');

  return { app, logger };
};

/***/ }),
/* 8 */
/***/ (function(module, exports) {

module.exports = require("path");

/***/ }),
/* 9 */
/***/ (function(module, exports) {

module.exports = require("koa-static");

/***/ }),
/* 10 */
/***/ (function(module, exports) {

module.exports = require("koa-mount");

/***/ }),
/* 11 */
/***/ (function(module, exports) {

module.exports = require("koa-views");

/***/ }),
/* 12 */
/***/ (function(module, exports) {

module.exports = require("koa-session");

/***/ }),
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  appenders: {
    console: { type: 'console' }
  },
  categories: {
    default: {
      level: process.env.LOG_LEVEL || 'debug',
      appenders: ['console']
    }
  }
};

/***/ }),
/* 14 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  key: 'fucking-nice-session.id',
  signed: false,
  rolling: true,
  httpOnly: process.env.NODE_ENV === 'development',
  maxAge: 5 * 3600 * 1000
};

/***/ }),
/* 15 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.enrichSession = exports.enrichResponse = undefined;

var _auth = __webpack_require__(1);

var _auth2 = _interopRequireDefault(_auth);

var _log4js = __webpack_require__(0);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const logger = (0, _log4js.getLogger)('middlewares');

/* Common response code
** Will be set to response as rtnCode */
const resCode = { success: 1, fail: -1 };

const commonRes = (ctx, status) => {
  return async (msg, obj = {}) => {
    const rtn = { rtnCode: status };

    if (msg instanceof Object) {
      obj = msg;
      msg = undefined;
    }

    status < 0 ? rtn.errMsg = msg || '请求失败' : rtn.rtnMsg = msg || '请求成功';

    Object.assign(rtn, obj);

    logger.debug(`Response data for request ${ctx.path}:`, JSON.stringify(rtn));

    return ctx.body = rtn;
  };
};

const enrichResponse = exports.enrichResponse = async (ctx, next) => {
  if (ctx.headers['x-request-token'] === _auth2.default['request-token'] && ctx.method === 'POST') {
    !ctx.success && (ctx.success = commonRes(ctx, resCode.success));
    !ctx.error && (ctx.error = commonRes(ctx, resCode.fail));
  }

  await next();
};

const enrichSession = exports.enrichSession = async (ctx, next) => {
  if (process.env.NODE_ENV === 'development' && !ctx.session.user) {
    if (ctx.cookies.get('dev-user')) {
      ctx.session.user = JSON.parse(ctx.cookies.get('dev-user'));
    } else if (ctx.headers['x-dev-token'] === _auth2.default['dev-token']) {
      ctx.session.user = { id: 'dev-user' };
    }
  }

  if (ctx.session.user) {
    ctx.state.user = ctx.session.user;
  }

  await next();
};

/***/ }),
/* 16 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = async (ctx, next) => {
  if (ctx.path.match(/^\/api\/user\//)) {
    return await __webpack_require__(17).default.routes()(ctx, next);
  }

  if (ctx.path.match(/^\/api\/trade\//)) {
    return await __webpack_require__(26).default.routes()(ctx, next);
  }
};

/***/ }),
/* 17 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _base = __webpack_require__(18);

var _base2 = _interopRequireDefault(_base);

var _user = __webpack_require__(20);

var _user2 = _interopRequireDefault(_user);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const userRouterConf = {
  controller: _user2.default,
  useBody: true
};

exports.default = (0, _base2.default)(userRouterConf);

/***/ }),
/* 18 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _koaRouter = __webpack_require__(2);

var _koaRouter2 = _interopRequireDefault(_koaRouter);

var _koaBody = __webpack_require__(19);

var _koaBody2 = _interopRequireDefault(_koaBody);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = opts => {
  const Controller = opts.controller;
  const instance = new Controller();
  const router = new _koaRouter2.default({ prefix: Controller._prefix });

  if (opts.useBody) {
    router.use((0, _koaBody2.default)(opts.bodyOpts));
  }

  for (let key in instance) {
    let route = instance[key];
    let config = route.config;
    router[config.method](config.path, ...route.middlewares, route.handler);
  }

  return router;
};

/***/ }),
/* 19 */
/***/ (function(module, exports) {

module.exports = require("koa-body");

/***/ }),
/* 20 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _dec, _dec2, _dec3, _class, _desc, _value, _class2;

var _base = __webpack_require__(21);

var _base2 = _interopRequireDefault(_base);

var _decipher = __webpack_require__(22);

var _decipher2 = _interopRequireDefault(_decipher);

var _decorator = __webpack_require__(25);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) {
  var desc = {};
  Object['ke' + 'ys'](descriptor).forEach(function (key) {
    desc[key] = descriptor[key];
  });
  desc.enumerable = !!desc.enumerable;
  desc.configurable = !!desc.configurable;

  if ('value' in desc || desc.initializer) {
    desc.writable = true;
  }

  desc = decorators.slice().reverse().reduce(function (desc, decorator) {
    return decorator(target, property, desc) || desc;
  }, desc);

  if (context && desc.initializer !== void 0) {
    desc.value = desc.initializer ? desc.initializer.call(context) : void 0;
    desc.initializer = undefined;
  }

  if (desc.initializer === void 0) {
    Object['define' + 'Property'](target, property, desc);
    desc = null;
  }

  return desc;
}

let UserController = (_dec = (0, _decorator.controller)('/api/user'), _dec2 = (0, _decorator.route)('/login', 'post', _decipher2.default), _dec3 = (0, _decorator.route)('/register', 'post'), _dec(_class = (_class2 = class UserController extends _base2.default {
  constructor() {
    super('user');
  }

  async login(ctx) {
    this.logger.info('user is about to login');
    return await ctx.success('Logged in!' + this.test(), { content: ctx.request.body });
  }

  async register(ctx) {
    this.logger.info('user is about to register');
    return await ctx.success('Register in!', { content: ctx.request.body });
  }

  test() {
    this.logger.info('testing');
    return 'hahahaha';
  }
}, (_applyDecoratedDescriptor(_class2.prototype, 'login', [_dec2], Object.getOwnPropertyDescriptor(_class2.prototype, 'login'), _class2.prototype), _applyDecoratedDescriptor(_class2.prototype, 'register', [_dec3], Object.getOwnPropertyDescriptor(_class2.prototype, 'register'), _class2.prototype)), _class2)) || _class);
exports.default = UserController;

/***/ }),
/* 21 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = undefined;

var _lodash = __webpack_require__(3);

var _lodash2 = _interopRequireDefault(_lodash);

var _log4js = __webpack_require__(0);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/*****************
* Base controller *
******************/
const setNativeProperty = (target, key, value) => {
  Object.defineProperty(target, key, {
    value: value,
    enumerable: false,
    configurable: true,
    writable: false
  });
};

let BaseController = class BaseController {
  constructor(name) {
    setNativeProperty(this, 'logger', (0, _log4js.getLogger)(name));
    setNativeProperty(this, '_', _lodash2.default);

    // add shotcuts for lodash methods
    Object.keys(_lodash2.default).forEach(key => setNativeProperty(this, `_${key}`, _lodash2.default[key]));
  }
};
exports.default = BaseController;

/***/ }),
/* 22 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _lodash = __webpack_require__(3);

var _lodash2 = _interopRequireDefault(_lodash);

var _log4js = __webpack_require__(0);

var _helper = __webpack_require__(23);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const logger = (0, _log4js.getLogger)('decipher');

exports.default = async (ctx, next) => {
  logger.info('Start to decrypting request data');

  const requestBody = _lodash2.default.get(ctx, 'request.body');
  const cipherText = _lodash2.default.get(requestBody, 'cipher');

  if (_lodash2.default.isEmpty(requestBody) || _lodash2.default.isNil(cipherText)) {
    logger.warn(`Encrypted request post to ${ctx.path} does not contains cipher`);
    return next();
  }

  if (process.env.NODE_ENV !== 'production') {
    logger.debug('Original request body:', JSON.stringify(_lodash2.default.get(requestBody, 'origin')));
  }

  try {
    logger.info('Decrypting cipher', cipherText);
    let decrypted = await (0, _helper.decrypt)(cipherText);

    if (_lodash2.default.isNil(decrypted)) {
      logger.warn('Successfully decrypted request data. But it is empty');
    } else {
      logger.debug('Successfully decypted request data:', decrypted);
      ctx.request.body = JSON.parse(decrypted);
    }
  } catch (err) {
    logger.error('Error in decrypt process:', err);
  } finally {
    await next();
  }
};

/***/ }),
/* 23 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.decrypt = undefined;

var _crypto = __webpack_require__(24);

var _auth = __webpack_require__(1);

const blockDecrypt = block => {
  try {
    const decrypted = (0, _crypto.privateDecrypt)({
      key: _auth.privateKey,
      padding: _crypto.constants.RSA_PKCS1_PADDING
    }, block);
    return decrypted;
  } catch (err) {
    if (block.length === 128) {
      return blockDecrypt(block.slice(0, 127));
    }

    throw err;
  }
};

const decrypt = exports.decrypt = cipher => {
  if (!cipher) {
    throw new Error('ciper cannot be null');
  }

  let rtn = '';

  const buffer = Buffer.from(cipher, 'base64');
  const blocks = Math.ceil(buffer.length / 128);

  for (let i = 0; i < blocks; i++) {
    rtn += blockDecrypt(buffer.slice(i * 128, (i + 1) * 128));
  }

  return decodeURI(rtn);
};

/***/ }),
/* 24 */
/***/ (function(module, exports) {

module.exports = require("crypto");

/***/ }),
/* 25 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
const controller = exports.controller = path => {
  return target => {
    target._prefix = path;
  };
};

const route = exports.route = (path, method = 'get', middlewares = []) => {
  return (target, key, descriptor) => {
    let fn = descriptor.value;

    if (typeof fn !== 'function') {
      throw new SyntaxError('@route can only be used on methods, not: ' + fn);
    }

    if (middlewares instanceof Function) {
      middlewares = [middlewares];
    }

    fn._route = { path, method };

    return {
      configurable: descriptor.configurable,
      enumerable: true,
      get() {
        return {
          config: { path, method },
          middlewares: middlewares,
          handler: fn.bind(this)
        };
      },
      set() {
        throw new SyntaxError('cannot assign new value to @route method');
      }
    };
  };
};

/***/ }),
/* 26 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _koaRouter = __webpack_require__(2);

var _koaRouter2 = _interopRequireDefault(_koaRouter);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const router = new _koaRouter2.default({ prefix: '/api/trade' });

router.post('/book', async ctx => {
  // logger.info('booking new trade')
  return await ctx.success('New trade booked!');
});

exports.default = router;

/***/ })
/******/ ]);